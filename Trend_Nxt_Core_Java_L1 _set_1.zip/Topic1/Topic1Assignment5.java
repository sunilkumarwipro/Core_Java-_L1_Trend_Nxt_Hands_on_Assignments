/*
Assignment 5:
Write a program that will accept a 4 digit number(assume that the user enters only 4 digit nos.)
and print the sum of all the 4 digits. For ex : If the number passed is 3629, the program should
print �The sum of all the digits entered is 20�
*/
import java.util.*;
public class Topic1Assignment5
{
	public static void main(String[] args) {
	Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int i=0,sum=0,temp=0;
		while(n>0)
		{
		    if(i<4)
		    {
		        temp=n%10;
		        sum+=temp;
		        n/=10;
		        i++;
		    }
		    else
		    System.exit(0);
		}
	   System.out.println(sum);
	}
}