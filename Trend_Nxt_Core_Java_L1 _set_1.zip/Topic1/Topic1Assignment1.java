/* Assignment 1:
Write a java program to display �Welcome to Java Programming� and then print your name on a
separate line
*/
public class Topic1Assignment1
{
    public static void main(String args[])
    {
        System.out.println("Welcome to Java Proramming");
        System.out.println("Guduru Sunil Kumar");
    }
}