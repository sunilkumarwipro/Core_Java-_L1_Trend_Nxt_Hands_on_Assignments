/*
Assignment 2:
Write a Java program to print the result of the following operations. Declare variables and
initialize them with given values 
*/
public class Topic1Assignment2
{
	public static void main(String[] args) {
		 int d1=-5,d2=8,d3=6;
		 int d4=55,d5=9;
		 int d6=20,d7=3,d8=5;
		 int d10=15,d11=2,d12=8;
		 System.out.println(d1+d2*d3);
		 System.out.println((d4+d5)%d5);
		 System.out.println(d6+-d7*d8/d2);
		 System.out.println(d8+d10/d7*d11-d12%d7);
	}
}
