/*
Assignment 6:
Write a program to find greatest number in an array
*/
public class Topic1Assignment6
{
	public static void main(String[] args) 
{
		int a[]={210,20,40,50,60,120,2,3,4,9,56,399};
		int big=0;
		for(int i=0;i<a.length;i++)
		{
		    if(a[i]>a[big])
		    {
		        a[big]=a[i];
		    }
		}
		System.out.println(a[big]);
	}
}