/*
Assignment 7:
Write a Java program to calculate the factorial of a number without using any loop.
*/
import java.util.*;
public class TopicAssignment7
{
	 public static void main(String[] args) {
	 Scanner in=new Scanner(System.in);
     int n=in.nextInt();
     System.out.println("factorial:"+factorial(n));
	}
	static int factorial(int n)
	{
	    if(n==0)
	    return 1;
	    else
	    return(n*(factorial(n-1)));
	}
}