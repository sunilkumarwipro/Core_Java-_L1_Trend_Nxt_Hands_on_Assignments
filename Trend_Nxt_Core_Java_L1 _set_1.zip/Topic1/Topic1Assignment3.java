/*
Assignment 3:
Write a Java program to convert minutes into a number of years and days
*/
import java.util.*;
public class Main
{
	public static void main(String args[]) 
	{
		Scanner in=new Scanner(System.in);
		int min=in.nextInt();
		long years=(long)min/(60*24*365);
		int days=(int)(min/60/24)%365;
		System.out.println("Years:"+years);
		System.out.println("Days:"+days);
	}
}
