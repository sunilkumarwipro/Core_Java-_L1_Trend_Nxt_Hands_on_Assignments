/*
Assignment 5:
Write a program to check the no.of occurrences of a given character within the given string
without using any loop. [Hint: String str=�How was your day today�; char c=�a�; no.of
occurrences of a is=3]
*/


package Assignment5;
import java.util.*;
public class FindNoOccurence {
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		System.out.println("Enter a String");
		String input=in.nextLine();
		System.out.println("Enter a character");
		char c=in.next().charAt(0);
		long count = input.chars().filter(ch -> ch == c).count();
        System.out.println(count);
		
	}

}
