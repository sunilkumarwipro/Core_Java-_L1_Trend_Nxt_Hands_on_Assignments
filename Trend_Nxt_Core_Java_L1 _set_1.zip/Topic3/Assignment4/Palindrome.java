/*
Assignment 4:
Write a program to check whether the given string is a palindrome or not.
[Hint :You have to extract each character from the beginning and end of the String and compare
it with each other. String x=�Malayalam�; char c= x.charAt(i) where i is the index]
*/


package Assignment4;
import java.util.*;
public class Palindrome {
public static void main(String args[])
{
	Scanner in=new Scanner(System.in);
	String input=in.next();
	String palindrome="";
	for(int i=input.length()-1;i>=0;i--)
		palindrome+=input.charAt(i);
	if(input.equals(palindrome))
	System.out.println(palindrome+": is palindrome");
	else
		System.out.println(palindrome+": is not palindrome");
}
}
