/*
Assignment 3:
Write a program to accept 5 integers passed as arguments while executing the class. Find the
average of these 5 nos. Use ArrayIndexOutofBounds exception to handle situation where the
user might have entered less than 5 integers.
*/


package Assignment3;

public class arrayindexoutofboundsexception {
	public static void main(String args[])
	{
		int average=0;
		try
		{
			for(int i=0;i<5;i++)
			{
				average+=Integer.parseInt(args[i]);
			}
			System.out.println(average/5);
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			ex.printStackTrace();
		}
	}

}
