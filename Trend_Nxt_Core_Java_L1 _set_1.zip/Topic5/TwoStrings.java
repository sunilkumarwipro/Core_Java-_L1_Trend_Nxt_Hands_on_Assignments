/*
Assignment 2:
Write a Program to accept two Strings Wipro Bangalore as command line arguments and print
the output �Wipro Technologies Bangalore� If the command line is �ABC Mumbai�, then it
should print �ABC Technologies Mumbai�.
*/


public class TwoStrings
{
	public static void main(String[] args) {
		String string=args[0]+" Technologies "+args[1];
		System.out.println(string);
	}
}