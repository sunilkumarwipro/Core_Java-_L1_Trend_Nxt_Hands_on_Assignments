package testpackage;
class foundation
{
  private int Var1=1;
  int Var2=2;
  protected int Var3=3;
  public int Var4=4;
}