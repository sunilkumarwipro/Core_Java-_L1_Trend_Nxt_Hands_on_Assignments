/*
Assignment 1:
Write a program to create a class Book with the following
- attributes: -isbn, title, author, price
 - methods :
 i. Initialize the data members through parameterized constructor
 ii. displaydeta ils() to display the details of the book
 iii. discountedprice() : pass the discount percent, calculate the discount on price and find
the amount to be paid after discount
 - task :
 Create an object book, initialize the book and display the details along with the discounted
price
*/


public class Main
{
	 public static void main(String[] args) {
	 Book book=new Book(1012,"java","James Gossling",1000);// isbn long,author String,title String,int price
	 book.displaydetails();
	 book.discountedprice(5);
	 }
}
class Book
{
    String title,author;
    long isbn;
    int price,discount;
    double finalprice;
    public Book(long isbn,String title,String author,int price)
    {
        this.isbn=isbn;
        this.title=title;
        this.author=author;
        this.price=price;
    }
    public void  displaydetails()
    {
    System.out.println("Isbn:"+isbn);
    System.out.println("Title:"+title);
    System.out.println("Author:"+author);
    System.out.println("Price:"+price);
    }
    public void discountedprice(int discount)
    {
        double temp=(double)discount/100;
        finalprice=price-(temp*price);
        System.out.println("Final Price:"+finalprice);
    }
}