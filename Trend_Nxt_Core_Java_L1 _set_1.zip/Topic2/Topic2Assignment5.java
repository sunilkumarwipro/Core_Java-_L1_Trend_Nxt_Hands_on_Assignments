/*
Assignment 5:
Create an abstract class Instrument which is having the abstract function play.
Create three more sub classes from Instrument which is Piano, Flute, Guitar.
Override the play method inside all three classes printing a message
�Piano is playing tan tan tan tan � for Piano class
�Flute is playing toot toot toot toot� for Flute class
�Guitar is playing tin tin tin � for Guitar class
You must not allow the user to declare an object of Instrument class.
Create an array of 10 Instruments.
Assign different type of instrument to Instrument reference.
Check for the polymorphic behavior of play method.
Use the instanceof operator to print that which object stored at which index of instrument array.
*/


class Topice2Assignment5
{
    public static void main(String args[])
    {
        Instrument instrument[]=new Instrument[10];
        instrument[0]=new Fluto();
        instrument[1]=new Piano();
        instrument[2]=new Guitar();
        instrument[3]=new Fluto();
        instrument[4]=new Piano();
        instrument[5]=new Guitar();
        instrument[6]=new Fluto();
        instrument[7]=new Piano();
        instrument[8]=new Guitar();
        instrument[9]=new Fluto();
        for(int i=0;i<9;i++)
        {
            if(instrument[i] instanceof Fluto)
                instrument[i].play();
            else if(instrument[i] instanceof Piano)
                instrument[i].play();
            else if(instrument[i] instanceof Guitar)
                instrument[i].play();
        }
    }
}
abstract class Instrument
{
    public void play()
    {
        
    }
}
class Piano extends Instrument
{
    public void play()
    {
        System.out.println("Piano is playing tan tan tan tan");
    }
}
class Fluto extends Instrument
{
    public void play()
    {
        System.out.println("Flute is playing toot toot toot toot");
    }
}
class Guitar extends Instrument
{
    public void play()
    {
        System.out.println("Guitar is playing tin tin tin");
    }
}