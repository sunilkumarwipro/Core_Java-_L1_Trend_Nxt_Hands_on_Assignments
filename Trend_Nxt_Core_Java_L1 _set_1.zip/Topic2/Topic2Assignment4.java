/*
Assignment 4:
Define a class named Payment that contains a member variable of type double that stores the
amount of the payment and appropriate accessor and mutator methods. Also create a method
named paymentDetails that outputs an English sentence to describe the amount of the payment.
Next, define a class named CashPayment that is derived from Payment. This class should
redefine the paymentDetails method to indicate that the payment is in cash. Include appropriate
constructor(s).
Define a class named CreditCardPayment that is derived from Payment. This class should
contain member variables for the name on the card, expiration date, and credit card number.
Include appropriate constructor(s). Finally, redefine the paymentDetails method to include all
credit card information in the printout.
Create a main method that creates at least two CashPayment and two
CreditCardPayment objects with different values and calls paymentDetails for each.
*/


class TopiceAssignment4 
{
    public static void main(String args[])
    {
        CashPayment cashpayment1=new CashPayment(150);
        CashPayment cashPayment2=new CashPayment(250);
        CreditCardPayment creditcardpayment1=new CreditCardPayment("SunilKumarivc","12/23","9666767583",3600);
        CreditCardPayment creditcardpayment2=new CreditCardPayment("Saikumarivc","06/26","9000960372",4200);
        cashpayment1.paymentDetails();
        cashPayment2.paymentDetails();
        creditcardpayment1.paymentDetails();
        creditcardpayment2.paymentDetails();
    }
}
class Payment
{
    double amount;
    Payment(double amount)
    {
        this.amount=amount;
    }
    public void setAmount(double amount)
    {
        this.amount=amount;
    }
    public double getAmount(double amount)
    {
        return this.amount;
    }
    public void paymentDetails()
    {
        System.out.println("amount of the payment:"+amount);
    }
}
class CashPayment extends Payment
{
    CashPayment(double amount)
    {
        super(amount);
    }
    public void paymentDetails()
    {
        System.out.println("----------CashPayment----------");       
        System.out.println("amount of the payment:"+amount);
    }
}
class CreditCardPayment extends Payment
{
    String nameoncard,expiredate,creditcardno;
    CreditCardPayment(String nameoncard,String expiredate,String creditcardno,int amount)
    {
        super(amount);
        this.nameoncard=nameoncard;
        this.expiredate=expiredate;
        this.creditcardno=creditcardno;
    }
    public void paymentDetails()
    {
        System.out.println("----------CreditCardPayment----------------");
        System.out.println("nameoncard:"+this.nameoncard);
        System.out.println("expiredate:"+this.expiredate);
        System.out.println("creditcardno:"+this.creditcardno);
        System.out.println("amount:"+amount);
    }
}