/*
Assignment 2:
Define a class named Document that contains a member variable of type String named text that
stores any textual content for the document. Create a method named toString that returns the text
field and also include a method to set this value.
Next, define a class for Email that is derived from Document and includes member variables for
the sender, recipient, and title of an email message. Implement appropriate accessor and mutator
methods. [An accessor is a member function that accesses the contents of an object but does not
modify that object; eg: int getX(return x;)A mutator is a member function that can modify an
object void setX(int x){this.x=x;} ]The body of the email message should be stored in the
inherited variable text. Redefine the toString method to concatenate all text fields.
*/


public class Topic2Assignment2  {
	 public static void main(String[] args) {
	 Email email=new Email("Welcome to wipro","guduru.Kumar1@wipro.com","saikumarivc@wipro.com","Congragulations");
	 System.out.println(email.toString());
	 }
}
class Document
{
    String text;
    Document(String text)
    {
        this.text=text;
    }
    public void setText(String text)
    {
        this.text=text;
    }
    public String toString()
    {
        return text;
    }
}
class Email extends Document
{
    String sender,recipient,title;
    Email(String text,String sender,String recipient,String title)
    {
        super(text);
        this.sender=sender;
        this.recipient=recipient;
        this.title=title;
    }
    public void setSender(String sender)
    {
        this.sender=sender;
    }
    public void setRecipient(String recipient)
    {
        this.recipient=recipient;
    }
    public void setTitle(String title)
    {
        this.title=title;
    }
    public String getSender()
    {
        return this.sender;
    }
    public String getRecipient()
    {
        return this.recipient;
    }
    public String getTitle()
    {
        return this.title;
    }
    public String toString()
    {
        return "Sender:"+this.sender+"\nRecipient:"+this.recipient+"\nTitle:"+this.title+"\n"+super.toString();
    }
}