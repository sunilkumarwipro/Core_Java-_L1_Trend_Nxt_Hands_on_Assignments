/*
Assignment 3:
Write a program to create a class Book with the following data members: isbn, title and price.
Inherit the class Book to two derived classes : Magazine and Novel with the following data
members:
Magazine: type
Novel : author
Populate the details using constructors.
Create a magazine and Novel and display the details.
*/


public class Topic2Assignment3
{
	 public static void main(String[] args) 
	 {
	  Magazine magazine=new Magazine("film","Pawan Kalyan","10502","The Leader",140);  
	  System.out.println(magazine.toString());
	 }
}
class Book
{
    String isbn,title;
    int price;
    Book()
    {
        
    }
    Book(String isbn,String title,int price)
    {
        this.isbn=isbn;
        this.title=title;
        this.price=price;
    }
}
class Magazine extends Book
{
    String type;
   Novel n;
    Magazine(String type,String author,String isbn,String title,int price)
    {
        super(isbn,title,price);
        this.type=type;
        n=new Novel(author);
    }
    public String toString()
    {
        return "isbn:"+isbn+"\ntitle:"+title+"\nprice:"+price+"\ntype:"+type+"\nauthor:"+n.toString();
    }
}
class Novel extends Book
{
    String author;
    Novel(String author)
    {
        this.author=author;
    }
    public String toString()
    {
        return author;
    }
}