/*
Assignment 2:
Write a Java Program which will print the current time on the console every 2 seconds.
After doing this activity for 20 seconds the program quits.
*/


package Assignment2;
import java.util.*;
class ThreadTimeSleep extends Thread {
    private String threadName;
    
    ThreadTimeSleep(String name) {
        threadName = name;
    }

    static void printDateTime() {
    	Formatter fmt = new Formatter();
        Calendar cal = Calendar.getInstance();
        fmt.format("%tr", cal);
        System.out.println(fmt);

    }
    
    public void run() {
        try {
        	
        	for(int i=0; i<20; i++) {
                printDateTime();
                Thread.sleep(2000);
            }
        }

            catch(InterruptedException e) {
                System.out.println("Thread " +  threadName + " interrupted.");
            }
        }
    }
public class TimeEvery2Seconds {
    public static void main(String args[]) {
        ThreadTimeSleep tt = new ThreadTimeSleep("MyThread");
        tt.start();
    }
}