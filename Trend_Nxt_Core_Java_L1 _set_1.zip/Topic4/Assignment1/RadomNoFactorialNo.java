/*
Assignment 1:
Write a Java Program, where one thread prints a number ( Generate a random number
using Math.random) and another thread prints the factorial of that given number. Both
the outputs should alternate each other.
Eg: Number : 2
 Factorial of 2 : 2
 Number : 5
 Factorial of 5 : 120
The program can quit after executing 5 times.
*/


package Assignment1;
import java.util.*;
public class RadomNoFactorialNo {
	public static void main(String args[])
	{
	    Thread1 thread1=new Thread1();
	    thread1.start();			
	}

}
class Thread1 extends Thread
{
	public void run()
	{
		for(int i=0;i<5;i++)
		{
		Random random=new Random();
		long l=(long)random.nextInt(50)+1;
		System.out.println("Number : "+l);
		Thread2 thread2=new Thread2(l);
		thread2.start();
		try {
			this.sleep(5);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				}
	}
}
class Thread2 extends Thread
{
	long n,fact=1;
	Thread2(long l)
	{
		n=l;
		for(int i=1;i<=n;i++){ 
			fact=fact*i; 
		  }  
	}
	public void run()
	{
		System.out.println("factorial of "+n+" is "+fact);
	}
}
