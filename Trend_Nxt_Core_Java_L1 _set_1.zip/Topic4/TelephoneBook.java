/*
Assignment 4:
Write a program creates a HashMap to store name and phone number (Telephone book). When
name is give, we can get back the corresponding phone number.
*/


import java.util.*;
class TelephoneBook
{
    public static void main(String args[])
    {
        HashMap<String,String> TelephoneDirectory=new HashMap<>();
        TelephoneDirectory.put("sunilkumarivc","9000960372");
        TelephoneDirectory.put("saikumarivc","9912345372");
        TelephoneDirectory.put("Mukundachari","9959758318");
        TelephoneDirectory.put("MalikBasha","7093430781");
        System.out.println(TelephoneDirectory.get("saikumarivc"));
    }
    
}