/*
Assignment 3:
Create an Employee class with the related attributes and behaviours. Create one more class
EmployeeDB which has the following methods.
a. boolean addEmployee(Employee e)
b. boolean deleteEmployee(int eCode)
c. String showPaySlip(int eCode)
d. Employee[] listAll()
Use an ArrayList which will be used to store the emplyees and use enumeration/iterator to
process the employees.
*/


import java.util.*;
class Employee
{
    String empid,empname,payslip;
    Employee(String empid,String empname,String payslip)
    {
        this.empid=empid;
        this.empname=empname;
        this.payslip=payslip;
    }
    public String getEmpID()
    {
        return this.empid;
    }
    public String getEmpName()
    {
        return this.empname;
    }
    public String getPaySlip()
   {
       return this.payslip;
   }
    public String toString()
    {
        return ("empid:"+this.empid+"\nempname:"+this.empname+"\npayslip"+payslip);
    }
}
class EmployeeDB
{
    ArrayList employees=new ArrayList<>();
    public boolean addEmployee(String empid,String empname,String payslip)
    {
        try {
             Employee e=new Employee(empid,empname,payslip);
        employees.add(e);
        return true;
        } catch(Exception e) {
            return false;
        }
    }
    public boolean removeEmployee(String empid)
    {
        try
        {
        Iterator i=employees.iterator();
        while(i.hasNext())
        {  
            Employee temp=(Employee)i.next();
            if((temp.getEmpID()).equals(empid))
            {
                employees.remove(temp);
                return true;
            }
        }
        }
        catch(Exception e)
        {
            return false;
        }
        return false;
    }
    public String showPaySlip(String empid)
    {
        Iterator i=employees.iterator();
        while(i.hasNext())
        {
        Employee Temp=(Employee)i.next();
        if((Temp.getEmpID()).equals(empid))
        {
            return Temp.getPaySlip();
        }
        }
        return "Employee Not Found";
    }
    public void listAll()
    {
        Iterator i=employees.iterator();
        while(i.hasNext())
        {
           System.out.println(i.next().toString());
        }
    }
    
}
public class Employee
{
public static void main (String[] args) {
Scanner in=new Scanner(System.in);
EmployeeDB empdb=new EmployeeDB();
int c;
while(true)
{
  System.out.println("1.addEmployee\n2.deleteEmployee\n3.showpayslip\n4.listAll");
  c=in.nextInt();
    if(c==1)
    {
        System.out.println("Enter Employee Id");
        String empid=in.next();
        System.out.println("Enter Employee Name");
        String empname=in.next();
        System.out.println("Enter payslip");
        String payslip=in.next();
        empdb.addEmployee(empid,empname,payslip);
    }
    else if(c==2)
    {
        System.out.println("Enter Employee Id to remove");
        if(empdb.removeEmployee(in.next())==true)
            System.out.println("Employee Removed Successfully");
        else
            System.out.println("Employee Not Found");
    }
    else if(c==3)
    {
        System.out.println("Enter Employee Id:");
         String s=in.next();
         String payslip=empdb.showPaySlip(s);
         System.out.println(payslip);
    }
    else if(c==4)
    {
        empdb.listAll();
    }
}
 }
}