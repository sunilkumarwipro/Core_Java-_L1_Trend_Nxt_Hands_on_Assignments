/*
Assignment 5:
Write a program to store a group of employee names into a HashSet, retrieve the elements one by
one using an Iterator.
*/


import java.util.*;
class Employee
{
    public static void main(String args[])
    {
        HashSet<String> h=new HashSet<>();
        h.add("sunilkumarivc");
        h.add("saikumarivc");
        h.add("mukundachari");
        h.add("malikbasha");
        Iterator i=h.iterator();
        System.out.println("Employee Names:");
        while(i.hasNext())
        {
            System.out.println(i.next());
        }
    }
}